#include "utilisateurcnx.h"
#include "ui_utilisateurcnx.h"
#include "utilisateurs.h"
#include "ui_mainwindow.h"
#include "mainwindow.h"
#include <QMediaPlayer>
#include <QPropertyAnimation>

utilisateurcnx::utilisateurcnx(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::utilisateurcnx)
{
    ui->setupUi(this);

    QPropertyAnimation *animation = new QPropertyAnimation(ui->hamzacopyright, "geometry");
    animation->setDuration(150);
    animation->setStartValue(QRect(0, 0, 75, 60));
    animation->setEndValue(QRect(80, 50, 131, 120));
    animation->start();


    QPropertyAnimation *animation2 = new QPropertyAnimation(ui->img, "geometry");
    animation2->setDuration(150);
    animation2->setStartValue(QRect(40, -20, 651, 381));
    animation2->setEndValue(QRect(40, -10, 651, 381));
    animation2->start();


    QPropertyAnimation *animation3 = new QPropertyAnimation(ui->pushButton, "geometry");
    animation3->setDuration(150);
    animation3->setStartValue(QRect(410, 280, 51, 41));
    animation3->setEndValue(QRect(410, 280, 251, 41));
    animation3->start();


}

utilisateurcnx::~utilisateurcnx()
{
    delete ui;
}

void utilisateurcnx::on_pushButton_clicked()
{
    QMediaPlayer * sound = new QMediaPlayer();
    sound->setMedia(QUrl("qrc:/images/src/buttonsound.wav"));
    sound->play();
    sound->setVolume(10);
    dbutilistaeur ut;
    QString utilisateur,mdp;
    utilisateur=ui->utilisateur->text();
    mdp=ui->mdp->text();
    bool trouver=ut.utilisateurF1(utilisateur);
    bool trouver2=ut.mdpF1(mdp);

    if((!trouver&&!trouver2) || (!trouver&&trouver2) || (!trouver2&&trouver))
        ui->testlogs->setText("Mot de passe ou Utilisateur incorrecte.");
    else if(trouver&&trouver2)
    {



         ui->testlogs->setText("");
         auto mm = new MainWindow();
         mm->setAttribute(Qt::WA_DeleteOnClose);
         close();
         mm->show();
    }
}
