#ifndef CONTROLE_H
#define CONTROLE_H
#include <QSqlDatabase>
#include <QSqlError>
#include <QSqlQuery>
#include <QSqlQueryModel>

class contsais{
public:
    contsais();
    int suppmsg(QString id);
    int suppmsg2(QString id);

    bool chaine(QString ch);
};

#endif // CONTROLE_H
