#include "utilisateurs.h"
#include "mainwindow.h"
#include <QApplication>
#include <QMessageBox>

dbutilistaeur::dbutilistaeur(){

}

bool dbutilistaeur::utilisateurF1(QString utilisateurs){

    bool trouver=false;

    QSqlQuery query;
    query.exec("SELECT NOMP_GR FROM GR_IDENT WHERE NOMP_GR='"+utilisateurs+"'");
    while(query.next())
    {
        trouver=true;
    }
    return trouver;
}

bool dbutilistaeur::mdpF1(QString mdp){

    bool trouver=false;

    QSqlQuery query;
    query.exec("SELECT NOMP_GR FROM GR_IDENT WHERE PASS_GR='"+mdp+"'");
    while(query.next())
    {
        trouver=true;
    }
    return trouver;
}


bool dbutilistaeur::modifpass(QString pass){
    QSqlQuery query;
    query.exec("UPDATE GR_IDENT SET PASS_GR='"+pass+"'");
    return true;
}

bool dbutilistaeur::modifnom(QString nom){
    QSqlQuery query;
    query.exec("UPDATE GR_IDENT SET NOMP_GR='"+nom+"'");
    return true;
}

bool dbutilistaeur::modifimage(QString path){
    QSqlQuery query;
    query.exec("UPDATE GR_IDENT SET PHOTO_GR='"+path+"'");
    return true;
}
