#include "mainwindow.h"
#include "ui_mainwindow.h"
#include "stats.h"
#include "recs.h"
#include "controle.h"
#include "avis.h"
#include "utilisateurcnx.h"
#include "sqlconnection.h"
#include <QDate>
#include "utilisateurs.h"
#include <QMediaPlayer>
#include <QThread>
#include <QPropertyAnimation>
#include <QGraphicsOpacityEffect>

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);

    ui->statusbar->setHidden(true);
    QGraphicsOpacityEffect *opacity = new QGraphicsOpacityEffect;
    QPropertyAnimation *animation = new QPropertyAnimation(opacity, "opacity");
    ui->stats->setGraphicsEffect(opacity);
    animation->setDuration(700);
    animation->setStartValue(0);
    animation->setEndValue(1);
    animation->start();



    QPropertyAnimation *animation2 = new QPropertyAnimation(ui->logo, "geometry");
    animation2->setDuration(500);
    animation2->setStartValue(QRect(70,10,25,25));
    animation2->setEndValue(QRect(70,10,81,81));
    animation2->start();

    acceuilmanag am;
    QString userimgpath,nomp,emailp,nommcat,nommfilm,nommserv,meilcats,imgfilm,meiservs;
    int totavs,totrecs,pourcfs,pourcservs,pourccats,meilfs,stotets;
    userimgpath = am.userpic();
    nomp = am.usernom();
    totavs = am.totav();
    imgfilm = am.imgfilms();
    stotets = am.nbets();
    pourcfs = am.pourcf();
    pourccats = am.pourccat();
    pourcservs = am.pourcs();
    meilcats = am.meilcat();
    meilfs = am.cmeilf();
    totrecs = am.totrec();
    meiservs = am.meilserv();
    ui->acimg->setPixmap(userimgpath);
    ui->nompr->setText(nomp);
    ui->stotavf->setText(QString::number(totavs));
    ui->totaf->setText(QString::number(totavs));
    ui->sprcf->setText(QString::number(pourcfs));
    ui->smeilcat->setText(meilcats);
    ui->stotnbf->setText(QString::number(meilfs));
    ui->stotet->setText(QString::number(stotets));
    ui->imgfilm->setPixmap(imgfilm);
    ui->stotrec->setText(QString::number(totrecs));
    ui->totrec->setText(QString::number(totrecs));
    ui->smeiserv->setText(meiservs);
    ui->sprccat->setText(QString::number(pourccats));
    ui->sprcserv->setText(QString::number(pourcservs));

    ui->compte->setHidden(true);
    ui->films->setHidden(true);
    ui->recs->setHidden(true);
    ui->stats->setHidden(false);
}

MainWindow::~MainWindow()
{
    delete ui;
}


void MainWindow::on_statistiques_clicked()
{
    QMediaPlayer * sound = new QMediaPlayer();
    sound->setMedia(QUrl("qrc:/images/src/buttonsound.wav"));
    sound->play();
    sound->setVolume(10);
    ui->compte->setHidden(true);
    ui->films->setHidden(true);
    ui->recs->setHidden(true);
    ui->stats->setHidden(false);
    QPropertyAnimation *animation2 = new QPropertyAnimation(ui->pushButton, "geometry");
    animation2->setDuration(500);
    animation2->setStartValue(QRect(510,110,181,41));
    animation2->setEndValue(QRect(390,110,181,41));
    animation2->start();

}

void MainWindow::on_reclamations_clicked()
{


    QMediaPlayer * sound = new QMediaPlayer();
    sound->setMedia(QUrl("qrc:/images/src/buttonsound.wav"));
    sound->play();
    sound->setVolume(10);

    QStringList list=(QStringList()<<"Web Streaming"<<"Reservation En Ligne"<<"Offre");
    ui->ajserv->addItems(list);

    QStringList list2=(QStringList()<<"1"<<"2"<<"3"<<"4"<<"5");
    ui->ajet->addItems(list2);

    QStringList list3=(QStringList()<<"Web Streaming"<<"Reservation En Ligne"<<"Offre");
    ui->mserv->addItems(list3);

    QStringList list4=(QStringList()<<"1"<<"2"<<"3"<<"4"<<"5");
    ui->met->addItems(list4);

    QStringList list5=(QStringList()<<"0"<<"1");
    ui->mtrait->addItems(list5);

    QStringList list6=(QStringList()<<"ID_REC"<<"NOM_SERV"<<"DATE_REC"<<"ET_SERV"<<"TRAIT_REC");
    ui->trie->addItems(list6);

    QStringList list7=(QStringList()<<"asc"<<"desc");
    ui->order->addItems(list7);


    QStringList list9=(QStringList()<<"Avant"<<"Dans"<<"Apres");
    ui->spec->addItems(list9);

    ui->tabWidget->setCurrentIndex(0);
    ui->compte->setHidden(true);


    ui->films->setHidden(true);
    ui->recs->setHidden(false);
    ui->stats->setHidden(true);

    QPropertyAnimation *animation3 = new QPropertyAnimation(ui->label_24, "geometry");
    animation3->setDuration(500);
    animation3->setStartValue(QRect(160,10,221,21));
    animation3->setEndValue(QRect(190,10,221,21));
    animation3->start();

    QGraphicsOpacityEffect *opacity = new QGraphicsOpacityEffect;
    QPropertyAnimation *animation = new QPropertyAnimation(opacity, "opacity");
    ui->tabWidget->setGraphicsEffect(opacity);
    animation->setDuration(700);
    animation->setStartValue(0);
    animation->setEndValue(1);
    animation->start();

    QPropertyAnimation *animation2 = new QPropertyAnimation(ui->logo, "geometry");
    animation2->setDuration(500);
    animation2->setStartValue(QRect(70,10,25,25));
    animation2->setEndValue(QRect(70,10,81,81));
    animation2->start();

    QSqlQueryModel * modal=new QSqlQueryModel();
    QSqlQuery query;

    query.exec("SELECT * FROM GR_REC");
    modal->setQuery(query);
    ui->tableView->setModel(modal);

   ui->tableView->horizontalHeader()->setStretchLastSection(true);


}

void MainWindow::on_pushButton_2_clicked()
{
    QMediaPlayer * sound = new QMediaPlayer();
    sound->setMedia(QUrl("qrc:/images/src/buttonsound.wav"));
    sound->play();
    sound->setVolume(10);

    QString s = QDate::currentDate().toString();

    ui->ajdate->setText(s);
    ui->mdate->setText(s);
}

void MainWindow::on_pushButton_4_clicked()
{
    QMediaPlayer * sound = new QMediaPlayer();
    sound->setMedia(QUrl("qrc:/images/src/buttonsound.wav"));
    sound->play();
    sound->setVolume(10);

    QSqlQueryModel * modal=new QSqlQueryModel();
    QSqlQuery query;
    query.exec("SELECT * FROM GR_REC");
    modal->setQuery(query);
    ui->tableView->setModel(modal);

   ui->tableView->horizontalHeader()->setStretchLastSection(true);
}

void MainWindow::on_pushButton_3_clicked()
{
    QMediaPlayer * sound = new QMediaPlayer();
    sound->setMedia(QUrl("qrc:/images/src/buttonsound.wav"));
    sound->play();
    sound->setVolume(10);

    QString id,desc,nom,etoile,trait,date;
    bool test,test1;
    id=ui->ajid->text();
    desc=ui->ajdesc->text();
    nom=ui->ajserv->currentText();
    etoile=ui->ajet->currentText();
    date=ui->ajdate->text();
    contsais cn;


    test=cn.chaine(id);
    test1=cn.chaine(desc);




    if(!test && test1)
    {
        trait="";

        grec gr;
        gr.ajoutr(id,desc,nom,etoile,trait,date);
        ui->chkaj->setText("");

    }
    else{
        ui->chkaj->setText("Verifier votre saisie !!");
    }


}


void MainWindow::on_modif_clicked()
{
    QMediaPlayer * sound = new QMediaPlayer();
    sound->setMedia(QUrl("qrc:/images/src/buttonsound.wav"));
    sound->play();
    sound->setVolume(10);

    QString id,desc,nom,etoile,trait,date;
    id=ui->mid->text();
    desc=ui->mdesc->text();
    nom=ui->mserv->currentText();
    etoile=ui->met->currentText();
    date=ui->mdate->text();
    trait=ui->mtrait->currentText();

    bool test,test1;
    contsais cn;
    test=cn.chaine(id);
    test1=cn.chaine(desc);

    if(!test && test1)
    {

        grec gr;
        gr.modifr(id,desc,nom,etoile,trait,date);
        ui->chkaj_2->setText("");

    }
    else{
        ui->chkaj_2->setText("Verifier votre saisie !!");
    }







}

void MainWindow::on_suppbtn_clicked()
{
    QMediaPlayer * sound = new QMediaPlayer();
    sound->setMedia(QUrl("qrc:/images/src/buttonsound.wav"));
    sound->play();
    sound->setVolume(10);
    QString id;
    int test;
    id=ui->supid->text();
    bool test1;
    contsais cn;
    test1=cn.chaine(id);


    contsais cs;
    test=cs.suppmsg(id);
    grec gr;

    if(!test1)
    {
        ui->chkaj_3->setText("");
    if(test>0)
    {
        gr.suppr(id);
        ui->supsuc->setText("Supprimer Avec Success !");
}
    else
       ui->supf->setText("Non trouver Verifier l'ID !");
    }
    else
     ui->chkaj_3->setText("Verifier votre saisie !!");

}

void MainWindow::on_affid_clicked()
{
    QMediaPlayer * sound = new QMediaPlayer();
    sound->setMedia(QUrl("qrc:/images/src/buttonsound.wav"));
    sound->play();
    sound->setVolume(10);

    QString id;
    QSqlQueryModel * modal=new QSqlQueryModel();
    bool test1;
    contsais cn;
    id=ui->rechid->text();
    test1=cn.chaine(id);

    if(!test1){


    grec gr;
    modal=gr.rechid(id);
    ui->tableView->setModel(modal);
    ui->tableView->horizontalHeader()->setStretchLastSection(true);
    ui->chkaj_4->setText("");
    }

    else
    {
       ui->chkaj_4->setText("Verifier votre saisie !!");
    }

}

void MainWindow::on_trirech_2_clicked()
{
    QMediaPlayer * sound = new QMediaPlayer();
    sound->setMedia(QUrl("qrc:/images/src/buttonsound.wav"));
    sound->play();
    sound->setVolume(10);

    QString noms,condition;
    QString id;
    QSqlQueryModel * modal=new QSqlQueryModel();

    noms=ui->nbchar->text();
    condition=ui->spec->currentText();
    bool test1;
    contsais cn;
    test1=cn.chaine(noms);


if(test1){
    grec gr;
    modal=gr.rechnom(noms,condition);
    ui->tableView->setModel(modal);
    ui->tableView->horizontalHeader()->setStretchLastSection(true);
    ui->chkaj_4->setText("");
}

    else
    {
       ui->chkaj_4->setText("Verifier votre saisie !!");
    }


}

void MainWindow::on_trirech_clicked()
{
    QMediaPlayer * sound = new QMediaPlayer();
    sound->setMedia(QUrl("qrc:/images/src/buttonsound.wav"));
    sound->play();
    sound->setVolume(10);
    QString champ,condition;
    champ=ui->trie->currentText();
    condition=ui->order->currentText();
    grec gr;
    QSqlQueryModel * modal=new QSqlQueryModel();

    modal=gr.rechav(champ,condition);
    ui->tableView->setModel(modal);
    ui->tableView->horizontalHeader()->setStretchLastSection(true);
}

void MainWindow::on_avisfilms_clicked()
{


    QMediaPlayer * sound = new QMediaPlayer();
    sound->setMedia(QUrl("qrc:/images/src/buttonsound.wav"));
    sound->play();
    sound->setVolume(10);

    QStringList list=(QStringList()<<"Horreur"<<"Action"<<"Comedie");
    ui->ajcat->addItems(list);
    ui->modcatfilm->addItems(list);

    QStringList list2=(QStringList()<<"1"<<"2"<<"3"<<"4"<<"5");
    ui->ajetf->addItems(list2);
    ui->modetoilefilm->addItems(list2);

    QStringList list6=(QStringList()<<"NOM_F"<<"CAT_F"<<"NET_F"<<"DATE_F"<<"ID_F");
    ui->trie2->addItems(list6);

    QStringList list7=(QStringList()<<"asc"<<"desc");
    ui->order2->addItems(list7);

    QStringList list9=(QStringList()<<"Avant"<<"Dans"<<"Apres");
    ui->spec_2->addItems(list9);


    QSqlQueryModel * modal=new QSqlQueryModel();
    QSqlQuery query;

    query.exec("SELECT * FROM GR_FILM");
    modal->setQuery(query);
    ui->tabview2->setModel(modal);

   ui->tabview2->horizontalHeader()->setStretchLastSection(true);

       ui->compte->setHidden(true);
    ui->films->setHidden(false);
    ui->recs->setHidden(true);
    ui->stats->setHidden(true);

    QPropertyAnimation *animation3 = new QPropertyAnimation(ui->label_59, "geometry");
    animation3->setDuration(500);
    animation3->setStartValue(QRect(130,10,221,21));
    animation3->setEndValue(QRect(170,10,241,21));
    animation3->start();

    QGraphicsOpacityEffect *opacity = new QGraphicsOpacityEffect;
    QPropertyAnimation *animation = new QPropertyAnimation(opacity, "opacity");
    ui->tabwidg3->setGraphicsEffect(opacity);
    animation->setDuration(700);
    animation->setStartValue(0);
    animation->setEndValue(1);
    animation->start();

    QPropertyAnimation *animation2 = new QPropertyAnimation(ui->logo, "geometry");
    animation2->setDuration(500);
    animation2->setStartValue(QRect(70,10,25,25));
    animation2->setEndValue(QRect(70,10,81,81));
    animation2->start();


    ui->tabwidg3->setCurrentIndex(0);
}

void MainWindow::on_ajf_clicked()
{
    QMediaPlayer * sound = new QMediaPlayer();
    sound->setMedia(QUrl("qrc:/images/src/buttonsound.wav"));
    sound->play();
    sound->setVolume(10);

    contsais cn;
    bool test,test1,test3;



    QString nom,cat,etoiles,datef,imgf,idf;
    nom=ui->ajnf->text();
    cat=ui->ajcat->currentText();
    etoiles=ui->ajetf->currentText();
    datef=ui->ajdatef->text();
    imgf=ui->ajimg->text();
    idf=ui->ajidf->text();
    test=cn.chaine(nom);
    test1=cn.chaine(cat);
    test3=cn.chaine(idf);

    if(test && test1 && !test3)
{
        ui->chkaj_5->setText("");
    gavis gv;

    gv.ajoutf(nom,cat,etoiles,datef,imgf,idf);
    }
    else
    {
        ui->chkaj_5->setText("Verifier votre saisie !!");
    }
}

void MainWindow::on_actus_clicked()
{
    QMediaPlayer * sound = new QMediaPlayer();
    sound->setMedia(QUrl("qrc:/images/src/buttonsound.wav"));
    sound->play();
    sound->setVolume(10);

    QSqlQueryModel * modal=new QSqlQueryModel();
    QSqlQuery query;
    query.exec("SELECT * FROM GR_FILM");
    modal->setQuery(query);
    ui->tabview2->setModel(modal);

   ui->tabview2->horizontalHeader()->setStretchLastSection(true);
}

void MainWindow::on_calend_clicked()
{
    QMediaPlayer * sound = new QMediaPlayer();
    sound->setMedia(QUrl("qrc:/images/src/buttonsound.wav"));
    sound->play();
    sound->setVolume(10);
    QString s = QDate::currentDate().toString();

    ui->ajdatef->setText(s);
    ui->moddatefilm->setText(s);

}

void MainWindow::on_modifierfilmbtn_clicked()
{
    QMediaPlayer * sound = new QMediaPlayer();
    sound->setMedia(QUrl("qrc:/images/src/buttonsound.wav"));
    sound->play();
    sound->setVolume(10);

    QString nom,cat,etoiles,datef,imgf,idf;
    nom=ui->modnomfilm->text();
    cat=ui->modcatfilm->currentText();
    etoiles=ui->modetoilefilm->currentText();
    datef=ui->moddatefilm->text();
    imgf=ui->monimagefilm->text();
    idf=ui->modidfilm->text();

    contsais cn;
    bool test,test1,test3;

    test=cn.chaine(nom);
    test1=cn.chaine(cat);
    test3=cn.chaine(idf);

    if(test && test1 && !test3)
    {
        ui->chkaj_6->setText("");

    gavis gv;

    gv.modiff(nom,cat,etoiles,datef,imgf,idf);
    }
    else
       ui->chkaj_6->setText("Verifier votre saisie !!");

}

void MainWindow::on_suppf_clicked()
{   
    QMediaPlayer * sound = new QMediaPlayer();
    sound->setMedia(QUrl("qrc:/images/src/buttonsound.wav"));
    sound->play();
    sound->setVolume(10);
    QString idf;
    int test;
    idf=ui->supprimerid->text();
    contsais cn;
    bool tests;
    tests=cn.chaine(idf);

    if(!tests){
    contsais cs;
    test=cs.suppmsg2(idf);
    gavis gv;


    if(test>0)
    {
        ui->chkaj_7->setText("");
        gv.suppf(idf);
        ui->supsuc_2->setText("Supprimer Avec Success !");
}
    else
       ui->supf_2->setText("Non trouver Verifier l'ID !");
    }

    else
      ui->chkaj_7->setText("Verifier votre saisie !!");


}

void MainWindow::on_affichertrie_clicked()
{
    QMediaPlayer * sound = new QMediaPlayer();
    sound->setMedia(QUrl("qrc:/images/src/buttonsound.wav"));
    sound->play();
    sound->setVolume(10);

    QString champ,condition;
    champ=ui->trie2->currentText();
    condition=ui->order2->currentText();


    gavis gv;
    QSqlQueryModel * modal=new QSqlQueryModel();

    modal=gv.rechavf(champ,condition);
    ui->tabview2->setModel(modal);
    ui->tabview2->horizontalHeader()->setStretchLastSection(true);

}

void MainWindow::on_afficherave_clicked()
{
    QMediaPlayer * sound = new QMediaPlayer();
    sound->setMedia(QUrl("qrc:/images/src/buttonsound.wav"));
    sound->play();
    sound->setVolume(10);

    QString noms,condition;
    QString id;
    QSqlQueryModel * modal=new QSqlQueryModel();
    contsais cn;
    bool tests;
    noms=ui->nbchar_2->text();
    condition=ui->spec_2->currentText();
    tests=cn.chaine(noms);
    if(tests)
    {
        ui->chkaj_8->setText("");


    gavis gv;
    modal=gv.rechnomf(noms,condition);
    ui->tabview2->setModel(modal);
    ui->tabview2->horizontalHeader()->setStretchLastSection(true);
    }
    else
    {
      ui->chkaj_8->setText("Verifier votre saisie !!");
    }
}

void MainWindow::on_afficherid_clicked()
{
    QMediaPlayer * sound = new QMediaPlayer();
    sound->setMedia(QUrl("qrc:/images/src/buttonsound.wav"));
    sound->play();
    sound->setVolume(10);
    QSqlQueryModel * modal=new QSqlQueryModel();
    QString idf;
    idf=ui->rechid_2->text();
    contsais cn;
    bool tests;
    tests=cn.chaine(idf);

    if(!tests){
        ui->chkaj_8->setText("Verifier votre saisie !!");
    gavis gv;
    modal=gv.rechidf(idf);
    ui->tabview2->setModel(modal);
    ui->tabview2->horizontalHeader()->setStretchLastSection(true);
    }
    else
      ui->chkaj_8->setText("Verifier votre saisie !!");
}

void MainWindow::on_cmtbtn_clicked()
{


    QMediaPlayer * sound = new QMediaPlayer();
    sound->setMedia(QUrl("qrc:/images/src/buttonsound.wav"));
    sound->play();
    sound->setVolume(10);

    QGraphicsOpacityEffect *opacity = new QGraphicsOpacityEffect;
    QPropertyAnimation *animation = new QPropertyAnimation(opacity, "opacity");
    ui->tabaccount->setGraphicsEffect(opacity);
    animation->setDuration(700);
    animation->setStartValue(0);
    animation->setEndValue(1);
    animation->start();

    QPropertyAnimation *animation2 = new QPropertyAnimation(ui->logo, "geometry");
    animation2->setDuration(500);
    animation2->setStartValue(QRect(70,10,25,25));
    animation2->setEndValue(QRect(70,10,81,81));
    animation2->start();

    ui->compte->setHidden(false);
 ui->films->setHidden(true);
 ui->recs->setHidden(true);
 ui->stats->setHidden(true);


    ui->tabaccount->setCurrentIndex(0);
    QStringList list=(QStringList()<<"Administrateur");
    ui->comboacc->addItems(list);

    acceuilmanag ag;
    QString userpic,nom,email;

    userpic=ag.userpic();
    nom = ag.usernom();
    email = ag.usermail();

    ui->imgac->setPixmap(userpic);
    ui->nomac->setText(nom);

    ui->acnom->setText(nom);
    ui->acmail->setText(email);
    ui->acimg_2->setPixmap(userpic);


}

void MainWindow::on_modifierfilmbtn_3_clicked()
{
    QString nom;
    nom=ui->chut->text();

    dbutilistaeur ut;
    ut.modifnom(nom);
    ui->chsucc->setText("Success !!");
}

void MainWindow::on_modifierfilmbtn_4_clicked()
{
    QString pass;
    pass=ui->chpass->text();

    dbutilistaeur ut;
    ut.modifpass(pass);
    ui->chsucc->setText("Success !!");
}

void MainWindow::on_modifierfilmbtn_5_clicked()
{
    QString path;
    path=ui->chimg->text();

    dbutilistaeur ut;
    ut.modifimage(path);
    ui->chsucc->setText("Success !!");
}

void MainWindow::on_modifierfilmbtn_2_clicked()
{
    QString userpic,nom,email;
    acceuilmanag ag;

    userpic=ag.userpic();
    nom = ag.usernom();
    email = ag.usermail();

    ui->acnom->setText(nom);
    ui->acmail->setText(email);
    ui->acimg_2->setPixmap(userpic);

}

void MainWindow::on_dcnx_clicked()
{    QMediaPlayer * sound = new QMediaPlayer();
     sound->setMedia(QUrl("qrc:/images/src/buttonsound.wav"));
     sound->play();
     sound->setVolume(10);
      QThread thread;
       thread.sleep(2);

    close();
}

void MainWindow::on_logof_linkHovered(const QString &link)
{

}
