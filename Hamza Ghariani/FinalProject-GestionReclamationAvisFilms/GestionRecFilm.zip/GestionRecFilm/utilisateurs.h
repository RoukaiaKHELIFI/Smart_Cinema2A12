#ifndef UTILISATEURS_H
#define UTILISATEURS_H
#include "mainwindow.h"
#include "ui_mainwindow.h"
#include <QSqlDatabase>
#include <QSqlError>
#include <QSqlQuery>

class dbutilistaeur
{
public:
    dbutilistaeur();
    bool utilisateurF1(QString utilistateurs);
    bool mdpF1(QString mdp);
    bool modifpass(QString pass);
    bool modifnom(QString nom);
    bool modifimage(QString path);
};

#endif // UTILISATEURS_H
