#include "controle.h"
#include "mainwindow.h"
#include <QApplication>
#include <QMessageBox>
#include "sqlconnection.h"

contsais::contsais(){

}

int contsais::suppmsg(QString id){
    QSqlQuery query;
    int number=0;

    query.exec("SELECT ID_REC FROM GR_REC WHERE ID_REC="+id);
    query.next();
    number=query.value(0).toInt();

    return number;

}

int contsais::suppmsg2(QString id){
    QSqlQuery query;
    int number=0;

    query.exec("SELECT ID_F FROM GR_FILM WHERE ID_F="+id);
    query.next();
    number=query.value(0).toInt();

    return number;

}


bool contsais::chaine(QString ch){
    bool test=false;
        for (int i = 0; i < ch.size(); i++)
        {
            if (ch[i].isDigit())
                test= false;
        else if(ch[i].isLetter())
                test=true;
        }

        return test;

}
