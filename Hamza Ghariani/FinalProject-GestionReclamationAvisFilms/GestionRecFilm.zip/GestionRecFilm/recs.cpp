#include "recs.h"
#include "mainwindow.h"
#include <QApplication>
#include <QMessageBox>
#include "sqlconnection.h"

grec::grec(){

}

bool grec::ajoutr(QString id, QString desc, QString noms, QString etserv,QString traitr, QString dater){
    QSqlQuery query;
    if(traitr.length()<=0)
        traitr="0";

    query.exec("INSERT INTO GR_REC (ID_REC, DESC_REC, NOM_SERV, ET_SERV, TRAIT_REC, DATE_REC) VALUES("+id+",'"+desc+"','"+noms+"',"+etserv+","+traitr+",'"+dater+"')");
    return true;
}

bool grec::modifr(QString id, QString desc, QString noms, QString etserv,QString traitr, QString dater){
    QSqlQuery query;

    query.exec("UPDATE GR_REC SET ID_REC="+id+",DESC_REC='"+desc+"',NOM_SERV='"+noms+"',ET_SERV="+etserv+",TRAIT_REC="+traitr+",DATE_REC='"+dater+"' WHERE ID_REC="+id);
    return true;
}

bool grec::suppr(QString id){

    QSqlQuery query;

    query.exec("DELETE FROM GR_REC WHERE ID_REC="+id);
    return true;

}


QSqlQueryModel* grec::rechid(QString id){
    QSqlQuery query;
    QSqlQueryModel * modal=new QSqlQueryModel();
    query.exec("SELECT * FROM GR_REC WHERE ID_REC="+id);
    modal->setQuery(query);
    return modal;
}



QSqlQueryModel* grec::rechnom(QString noms,QString condition){
    QString chaine;


    if(condition=="Avant")
        chaine=chaine+"%"+noms;
    if(condition=="Dans")
        chaine=chaine+"%"+noms+"%";
    if(condition=="apres")
        chaine=chaine+noms+"%";

    QSqlQuery query;
    QSqlQueryModel * modal=new QSqlQueryModel();
    query.exec("SELECT * FROM GR_REC WHERE NOM_SERV LIKE '"+chaine+"'");
    modal->setQuery(query);
    return modal;
}

QSqlQueryModel* grec::rechav(QString champ,QString condition){
    QSqlQuery query;
    QSqlQueryModel * modal=new QSqlQueryModel();
    query.exec("SELECT * FROM GR_REC ORDER BY "+champ+" "+condition);
    modal->setQuery(query);
    return modal;
}




