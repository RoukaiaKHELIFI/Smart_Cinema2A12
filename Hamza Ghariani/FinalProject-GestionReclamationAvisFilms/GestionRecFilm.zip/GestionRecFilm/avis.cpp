#include "avis.h"
#include "mainwindow.h"
#include <QApplication>
#include <QMessageBox>
#include "sqlconnection.h"

gavis::gavis(){

}

bool gavis::ajoutf(QString nom, QString cat, QString etoiles, QString datef,QString imgf, QString idf){
    QSqlQuery query;
    query.exec("INSERT INTO GR_FILM (NOM_F, CAT_F, NET_F, IMG_F, ID_F,DATE_F) VALUES('"+nom+"','"+cat+"',"+etoiles+",'"+imgf+"',"+idf+",'"+datef+"')");
    return true;
}


bool gavis::modiff(QString nom, QString cat, QString etoiles, QString datef,QString imgf, QString idf){
    QSqlQuery query;
    query.exec("UPDATE GR_FILM SET NOM_F='"+nom+"',CAT_F='"+cat+"',NET_F="+etoiles+",IMG_F='"+imgf+"',ID_F="+idf+",DATE_F='"+datef+"' WHERE ID_F="+idf);
    return true;
}

bool gavis::suppf(QString idf){
    QSqlQuery query;

    query.exec("DELETE FROM GR_FILM WHERE ID_F="+idf);
    return true;
}

QSqlQueryModel* gavis::rechidf(QString id){
    QSqlQuery query;
    QSqlQueryModel * modal=new QSqlQueryModel();
    query.exec("SELECT * FROM GR_FILM WHERE ID_F="+id);
    modal->setQuery(query);
    return modal;
}



QSqlQueryModel* gavis::rechnomf(QString noms,QString condition){
    QString chaine;


    if(condition=="Avant")
        chaine=chaine+"%"+noms;
    if(condition=="Dans")
        chaine=chaine+"%"+noms+"%";
    if(condition=="apres")
        chaine=chaine+noms+"%";

    QSqlQuery query;
    QSqlQueryModel * modal=new QSqlQueryModel();
    query.exec("SELECT * FROM GR_FILM WHERE NOM_F LIKE '"+chaine+"'");
    modal->setQuery(query);
    return modal;
}

QSqlQueryModel* gavis::rechavf(QString champ,QString condition){
    QSqlQuery query;
    QSqlQueryModel * modal=new QSqlQueryModel();
    query.exec("SELECT * FROM GR_FILM ORDER BY "+champ+" "+condition);
    modal->setQuery(query);
    return modal;
}

