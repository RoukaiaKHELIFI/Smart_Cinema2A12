#ifndef AVIS_H
#define AVIS_H
#include <QSqlDatabase>
#include <QSqlError>
#include <QSqlQuery>
#include <QSqlQueryModel>

class gavis{
public:
    gavis();
    bool ajoutf(QString nom, QString cat, QString etoiles, QString datef,QString imgf, QString idf);
    bool modiff(QString nom, QString cat, QString etoiles, QString datef,QString imgf, QString idf);
    bool suppf(QString idf);
    QSqlQueryModel* rechidf(QString idf);
    QSqlQueryModel* rechnomf(QString noms,QString condition);
    QSqlQueryModel* rechavf(QString champ,QString condition);

};

#endif // AVIS_H
