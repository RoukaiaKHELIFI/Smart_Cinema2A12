#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>

QT_BEGIN_NAMESPACE
namespace Ui { class MainWindow; }
QT_END_NAMESPACE

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    MainWindow(QWidget *parent = nullptr);
    ~MainWindow();

private slots:
    void on_statistiques_clicked();

    void on_reclamations_clicked();

    void on_pushButton_2_clicked();

    void on_pushButton_4_clicked();

    void on_pushButton_3_clicked();

    void on_modif_clicked();

    void on_suppbtn_clicked();

    void on_affid_clicked();

    void on_trirech_2_clicked();

    void on_trirech_clicked();

    void on_avisfilms_clicked();

    void on_ajf_clicked();

    void on_actus_clicked();

    void on_calend_clicked();

    void on_modifierfilmbtn_clicked();

    void on_suppf_clicked();

    void on_affichertrie_clicked();

    void on_afficherave_clicked();

    void on_afficherid_clicked();

    void on_cmtbtn_clicked();

    void on_modifierfilmbtn_3_clicked();

    void on_modifierfilmbtn_4_clicked();

    void on_modifierfilmbtn_5_clicked();

    void on_modifierfilmbtn_2_clicked();

    void on_dcnx_clicked();

    void on_logof_linkHovered(const QString &link);

private:
    Ui::MainWindow *ui;
};
#endif // MAINWINDOW_H
