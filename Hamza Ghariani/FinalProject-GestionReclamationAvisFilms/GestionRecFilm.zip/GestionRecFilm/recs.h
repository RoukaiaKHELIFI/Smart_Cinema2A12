#ifndef RECS_H
#define RECS_H
#include <QSqlDatabase>
#include <QSqlError>
#include <QSqlQuery>
#include <QSqlQueryModel>


class grec{
public:
    grec();
    bool ajoutr(QString id, QString desc, QString noms, QString etserv,QString traitr, QString dater);
    bool modifr(QString id, QString desc, QString noms, QString etserv,QString traitr, QString dater);
    bool suppr(QString id);
    QSqlQueryModel* rechid(QString id);
    QSqlQueryModel* rechnom(QString noms,QString condition);
    QSqlQueryModel* rechav(QString champ,QString condition);
};

#endif // RECS_H
