#ifndef UTILISATEURCNX_H
#define UTILISATEURCNX_H

#include <QDialog>

namespace Ui {
class utilisateurcnx;
}

class utilisateurcnx : public QDialog
{
    Q_OBJECT

public:
    explicit utilisateurcnx(QWidget *parent = nullptr);
    ~utilisateurcnx();

private slots:
    void on_pushButton_clicked();

private:
    Ui::utilisateurcnx *ui;
};

#endif // UTILISATEURCNX_H
