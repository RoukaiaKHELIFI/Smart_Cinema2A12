#include "facceuil.h"
#include "mainwindow.h"
#include <QApplication>
#include <QMessageBox>

acceuilmanag::acceuilmanag(){

}


QString acceuilmanag::userpic(){
        QSqlQuery query;
        QString text;
        query.exec("SELECT PHOTO_GR FROM GR_IDENT");
        query.next();
        text=query.value(0).toString();
        return text;

}

QString acceuilmanag::usernom(){
        QSqlQuery query;
        QString text;
        query.exec("SELECT NOMPREN FROM GR_IDENT");
        query.next();
        text=query.value(0).toString();
        return text;

}

QString acceuilmanag::usermail(){
        QSqlQuery query;
        QString text;
        query.exec("SELECT EMAIL_GR FROM GR_IDENT");
        query.next();
        text=query.value(0).toString();
        return text;

}


int acceuilmanag::totav(){
        QSqlQuery query;
        int number;
        query.exec("SELECT COUNT(NET_F) FROM GR_FILM");
        while(query.next())
        {
           number=query.value(0).toInt();
        }
        return number;
}



int acceuilmanag::totet(){
        QSqlQuery query;
        int number;
        query.exec("SELECT SUM(NET_F) FROM GR_FILM");
        while(query.next())
        {
           number=query.value(0).toInt();
        }
        return number;
}

int acceuilmanag::cmeilf(){
        QSqlQuery query;
        int number;
        query.exec("SELECT COUNT(NOM_F) FROM GR_FILM WHERE NET_F=5");
        query.next();

           number=query.value(0).toInt();

        return number;
}


int acceuilmanag::nbets(){
    QSqlQuery query;
    int number;
    query.exec("SELECT SUM(NET_F) FROM GR_FILM");
    query.next();

       number=query.value(0).toInt();

    return number;
}


QString acceuilmanag::imgfilms(){
    QSqlQuery query;
    QString text;
    query.exec("SELECT IMG_F FROM GR_FILM GROUP BY IMG_F HAVING COUNT(*)>1 ORDER BY SUM(NET_F) DESC;");
    query.next();
    text=query.value(0).toString();


    return text;
}


int acceuilmanag::pourcf(){
        QSqlQuery query,query2,query3;
        int number;
        QString nomf,sumetois;

        query3.exec("SELECT SUM(NET_F) FROM GR_FILM");
        query3.next();
        sumetois=query3.value(0).toString();

        query2.exec("SELECT NOM_F FROM GR_FILM GROUP BY NOM_F ORDER BY SUM(NET_F) DESC");
        query2.next();
        nomf=query2.value(0).toString();

        query.exec("SELECT (SUM(NET_F)*100/"+sumetois+")+50 FROM GR_FILM WHERE NOM_F='"+nomf+"'");
        query.next();
        number=query.value(0).toInt();
        return number;
}

int acceuilmanag::pourccat(){
    QSqlQuery query,query2,query3;
    int number;
    QString nomf,sumetois;

    query3.exec("SELECT SUM(NET_F) FROM GR_FILM");
    query3.next();
    sumetois=query3.value(0).toString();

    query2.exec("SELECT CAT_F FROM GR_FILM GROUP BY CAT_F ORDER BY SUM(NET_F) DESC");
    query2.next();
    nomf=query2.value(0).toString();

    query.exec("SELECT (SUM(NET_F)*100/"+sumetois+") FROM GR_FILM WHERE CAT_F='"+nomf+"'");
    query.next();
    number=query.value(0).toInt();
    return number;
}


int acceuilmanag::pourcs(){
    QSqlQuery query,query2,query3;
    int number;
    QString nomf,sumetois;

    query3.exec("SELECT SUM(ET_SERV) FROM GR_REC");
    query3.next();
    sumetois=query3.value(0).toString();

    query2.exec("SELECT NOM_SERV FROM GR_REC GROUP BY NOM_SERV ORDER BY SUM(ET_SERV) DESC");
    query2.next();
    nomf=query2.value(0).toString();

    query.exec("SELECT (SUM(ET_SERV)*100/"+sumetois+")+50 FROM GR_REC WHERE NOM_SERV='"+nomf+"'");
    query.next();
    number=query.value(0).toInt();
    return number;
}


QString acceuilmanag::meilcat(){
    QSqlQuery query;
    QString text;
    query.exec("SELECT CAT_F FROM GR_FILM GROUP BY CAT_F HAVING COUNT(*)>1 ORDER BY SUM(NET_F) DESC;");
    query.next();
    text=query.value(0).toString();


    return text;
}

int acceuilmanag::totrec(){
    QSqlQuery query;
    int number;
    query.exec("SELECT COUNT(ID_REC) FROM GR_REC");
    while(query.next())
    number=query.value(0).toInt();
    return number;
}

QString acceuilmanag::meilserv(){
    QSqlQuery query;
    QString text;
    query.exec("SELECT NOM_SERV FROM GR_REC GROUP BY NOM_SERV  HAVING COUNT(*)>1 ORDER BY SUM(ET_SERV) DESC;");
    query.next();
    text=query.value(0).toString();


    return text;
}
