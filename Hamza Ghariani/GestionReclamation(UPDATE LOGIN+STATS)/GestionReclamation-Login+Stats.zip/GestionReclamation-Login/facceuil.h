#ifndef FACCEUIL_H
#define FACCEUIL_H
#include <QSqlDatabase>
#include <QSqlError>
#include <QSqlQuery>

class acceuilmanag
{
public:
    acceuilmanag();
    QString userpic();
    QString usernom();
    QString usermail();
    int totrec();
    int totav();
    int totet();
    int pourcf();
    int pourcs();
    int pourccat();
    QString meilcat();
    int cmeilf();
    int nbets();
    QString imgfilms();
    QString meilserv();

};

#endif // FACCEUIL_H
