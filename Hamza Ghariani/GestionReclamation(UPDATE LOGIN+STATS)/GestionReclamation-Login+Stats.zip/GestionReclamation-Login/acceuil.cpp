#include "acceuil.h"
#include "facceuil.h"
#include "ui_acceuil.h"

acceuil::acceuil(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::acceuil)
{
    ui->setupUi(this);

    // Initialisation des images

    QPixmap developerlogo = QPixmap(":/img/acceuil/logo.png");
    ui->logo->setPixmap(developerlogo);
    QPixmap icons = QPixmap(":/img/acceuil/icons.png");
    ui->icons->setPixmap(icons);
    QPixmap iconsn2 = QPixmap(":/img/acceuil/icons2.png");
    ui->icons2->setPixmap(iconsn2);
    QPixmap iconsn3 = QPixmap(":/img/acceuil/icons3.png");
    ui->icons3->setPixmap(iconsn3);
    QPixmap sectionstat1 = QPixmap(":/img/acceuil/sections/stats-s1.png");
    ui->statss1->setPixmap(sectionstat1);
    QPixmap sectionstat2 = QPixmap(":/img/acceuil/sections/stats-s2.png");
    ui->sec2stat->setPixmap(sectionstat2);

    // Initialisation des donnes statistiques

    acceuilmanag am;
    QString userimgpath,nomp,emailp,nommcat,nommfilm,nommserv,meilcats,imgfilm,meiservs;
    int totavs,totrecs,pourcfs,pourcservs,pourccats,meilfs,stotets;
    userimgpath = am.userpic();
    nomp = am.usernom();
    emailp = am.usermail();
    totavs = am.totav();
    imgfilm = am.imgfilms();
    stotets = am.nbets();
    pourcfs = am.pourcf();
    pourccats = am.pourccat();
    pourcservs = am.pourcs();
    meilcats = am.meilcat();
    meilfs = am.cmeilf();
    totrecs = am.totrec();
    meiservs = am.meilserv();
    ui->acimg->setPixmap(userimgpath);
    ui->nompr->setText(nomp);
    ui->email->setText(emailp);
    ui->stotavf->setText(QString::number(totavs));
    ui->totaf->setText(QString::number(totavs));
    ui->sprcf->setText(QString::number(pourcfs));
    ui->smeilcat->setText(meilcats);
    ui->stotnbf->setText(QString::number(meilfs));
    ui->stotet->setText(QString::number(stotets));
    ui->imgfilm->setPixmap(imgfilm);
    ui->stotrec->setText(QString::number(totrecs));
    ui->totrec->setText(QString::number(totrecs));
    ui->smeiserv->setText(meiservs);
    ui->sprccat->setText(QString::number(pourccats));
    ui->sprcserv->setText(QString::number(pourcservs));
    // Controle des Widgets

    ui->grec->setHidden(true);
    ui->stats->setHidden(false);









}

acceuil::~acceuil()
{
    delete ui;
}

void acceuil::on_gftxt_clicked()
{
    ui->grec->setHidden(false);
    ui->stats->setHidden(true);
}

void acceuil::on_analysestxt_clicked()
{
    ui->grec->setHidden(true);
    ui->stats->setHidden(false);
}
