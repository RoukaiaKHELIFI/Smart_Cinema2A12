#include "mainwindow.h"
#include "ui_mainwindow.h"
#include "film.h"
#include "connection.h"
#include "QMessageBox"
MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    connection c;
    c.createconnect();
    ui->setupUi(this);
    ui->AfficherFilmTable->setModel(tmpc.afficher_film());
}

MainWindow::~MainWindow()
{
    delete ui;
}


void MainWindow::on_AjouterFilm_clicked()
{
    Film f(ui->id_film->text().toInt(),ui->nom_film->text(),ui->realisateur->text(),
                       ui->nationalite->currentText(),ui->date_sortie->date(),ui->disponibilite->text(),
                       ui->categorie->currentText());
               f.ajouter_film();

             //  ui->AfficherFilmTable->setModel(tmpc.afficher_film());
}

void MainWindow::on_SupprimerFilm_clicked()
{
    QItemSelectionModel *select=ui->AfficherFilmTable->selectionModel();
        QString idd=select->selectedRows(0).value(0).data().toString();
        Film *tmpCl=new Film();

            QString str = " Vous voulez vraiment supprimer \n le film  ayant le id :"+ ui->id_film->text();
                 int ret = QMessageBox::question(this, tr("suppression"),str,QMessageBox::Ok|QMessageBox::Cancel);
                 switch (ret) {
                   case QMessageBox::Ok:

                      tmpCl->setid_film(ui->id_film->text().toInt());
                       if (tmpCl->supprimer_film()){

                               ui->AfficherFilmTable->setModel(tmpc.afficher_film());
                       }break;
                   case QMessageBox::Cancel:

                       break;
                   default:
                       // should never be reached
                       break;
                 }
}

void MainWindow::on_Close_2_clicked()
{
    close();
}

void MainWindow::on_Close_ticket_clicked()
{
    close();
}
